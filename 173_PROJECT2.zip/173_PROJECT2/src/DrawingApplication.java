import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class DrawingApplication extends JFrame {
    private DrawingPanel drawingPanel;

    public DrawingApplication() {
        setTitle("Graphical Drawing Application");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        drawingPanel = new DrawingPanel();
        add(drawingPanel);
        setVisible(true);
    }

    private class DrawingPanel extends JPanel {
        private ArrayList<Shape> shapes = new ArrayList<>();

        public DrawingPanel() {
            setBackground(Color.WHITE);
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    // Add a circle at the mouse position
                    shapes.add(new Circle(e.getX(), e.getY(), 30));
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            shapes.forEach(shape -> shape.draw(g));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DrawingApplication::new);
    }

    interface Shape {
        void draw(Graphics g);
    }

    class Circle implements Shape {
        private int x, y, radius;

        public Circle(int x, int y, int radius) {
            this.x = x;
            this.y = y;
            this.radius = radius;
        }

        @Override
        public void draw(Graphics g) {
            g.setColor(Color.BLUE);
            g.fillOval(x - radius, y - radius, radius * 2, radius * 2);
        }
    }

    class Rectangle implements Shape {
        private int x, y, width, height;

        public Rectangle(int x, int y, int width, int height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }

        @Override
        public void draw(Graphics g) {
            g.setColor(Color.RED);
            g.fillRect(x, y, width, height);
        }
    }
}
