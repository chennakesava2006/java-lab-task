package commands;

public class Thermostat {
    private int temperature;

    public void setTemperature(int temperature) {
        this.temperature = temperature;
        System.out.println("Thermostat set to " + temperature + " degrees.");
    }

	public int getTemperature() {
		return temperature;
	}
}

class SetThermostatCommand implements Command {
    private Thermostat thermostat;
    private int temperature;
    private int prevTemperature;

    public SetThermostatCommand(Thermostat thermostat, int temperature) {
        this.thermostat = thermostat;
        this.temperature = temperature;
    }

    @Override
    public void execute() {
        prevTemperature = thermostat.getTemperature();
        thermostat.setTemperature(temperature);
    }

    @Override
    public void undo() {
        thermostat.setTemperature(prevTemperature);
    }
}
