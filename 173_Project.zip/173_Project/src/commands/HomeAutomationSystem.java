package commands;

public class HomeAutomationSystem {

    public static void main(String[] args) {
        RemoteControl remoteControl = new RemoteControl();

        Light livingRoomLight = new Light();
        Thermostat thermostat = new Thermostat();

        LightOnCommand livingRoomLightOn = new LightOnCommand(livingRoomLight);
        LightOffCommand livingRoomLightOff = new LightOffCommand(livingRoomLight);
        SetThermostatCommand setThermostat = new SetThermostatCommand(thermostat, 22);

        remoteControl.setCommand(0, livingRoomLightOn, livingRoomLightOff);
        remoteControl.setCommand(1, setThermostat, new NoCommand());

        // Turn on the light
        remoteControl.onButtonWasPushed(0);
        // Turn off the light
        remoteControl.offButtonWasPushed(0);
        // Undo last command (turn light back on)
        remoteControl.undoButtonWasPushed();

        // Set thermostat to 22 degrees
        remoteControl.onButtonWasPushed(1);
        // Undo thermostat change
        remoteControl.undoButtonWasPushed();
    }
}
